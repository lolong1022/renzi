<template>
  <div>
    social
  </div>
</template>

<script>
export default {
  name: 'HrsaasIndex',

  data() {
    return {

    }
  },

  mounted() {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
