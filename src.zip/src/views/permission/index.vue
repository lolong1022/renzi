<template>
  <div>
    permission
  </div>
</template>

<script>
export default {
  name: 'HrsaasIndex',

  data() {
    return {

    }
  },

  mounted() {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
